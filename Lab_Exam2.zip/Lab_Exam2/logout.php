<!DOCTYPE html>
<html>
<head>
	<title>Logout</title>
</head>
<body>
<script>window.location='home.php';</script>
</body>
</html>