
<html>
<head>
	<title>Profile</title>
</head>
<body>
<center>
<table border="1" width="60%">
	<tr>
		<td width="100"><img src="https://www.logofound.com/wp-content/uploads/2016/09/business-logo-company-01-230x230.jpg" height="100" width="100"></td>
		<td align="right"> Login as <a href="profile.php">Bob</a><a href="logout.php">| Logout</a> </td>
	</tr>
	<tr>
		<td width="20px">
			<p>Account</p>
			<hr>
			<ul>
				<li><a href="dashboard.php">Dashboard</a></li>
				<li><a href="profile.php">Profile</a></li>
				<li><a href="editprofile.php">Edit Profile</a></li>
				<li><a href="changepic.php">Change Profile Picture</a></li>
				<li><a href="changepass.php">Change Password</a></li>
				<li><a href="logout.php">Logout</a></li>
				
				
			</ul>
		</td>
		<td>
			<fieldset>
				<legend>PROFILE</legend>
				<form>
					<table border="0" width="50%">
						<tr>
							<td>Name</td>
							<td align="left">:Bob</td>
							<td rowspan="6"> <img src="https://cdn.business2community.com/wp-content/uploads/2017/08/blank-profile-picture-973460_640.png" height="100" width="100"></td>
						</tr>
						<tr><td colspan="2"><hr></td></tr>
						<tr>
							<td>Email</td>
							<td align="left">:bob@aiub.edu</td>
						</tr>
						<tr><td colspan="2"><hr></td></tr>
						<tr>
							<td>Gender</td>
							<td align="left">:Male</td>
						</tr>
						<tr><td colspan="2"><hr></td></tr>
						<tr>
							<td>Date of Birth</td>
							<td align="left">:19/09/1998</td>
						</tr>
						<tr><td colspan="2"><hr></td></tr>
						<tr>
							<td colspan="2"><input type="submit" name="submit"></td>
						</tr>
					</table>
				</form>
			</fieldset>
		</td>
	</tr>
		<td colspan="2" align="center">Copyright &copy; 2017</td>
	</tr>
</table>
</center>
</body>
</html>